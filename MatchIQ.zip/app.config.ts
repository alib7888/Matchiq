export default {
  logoUrl: "https://placehold.co/64x64/22c55e/06111f.png?text=M",
};
