import { useMemo, useState } from "react";
import { useLocation, useRoute } from "wouter";
import {
  Activity,
  AlertTriangle,
  ArrowLeft,
  BarChart3,
  BrainCircuit,
  CalendarDays,
  Check,
  ChevronLeft,
  ChevronRight,
  CircleHelp,
  Clock3,
  CloudOff,
  Gauge,
  LayoutDashboard,
  Menu,
  RefreshCw,
  Search,
  Settings2,
  ShieldCheck,
  SlidersHorizontal,
  Sparkles,
  Target,
  TrendingUp,
  Trophy,
  Users,
  X,
  Zap,
} from "lucide-react";
import { trpc } from "@/lib/trpc";
import type { Match, MatchStatus, Prediction, Team } from "../../../server/football";

type FilterStatus = MatchStatus | "all";

const statusLabel: Record<FilterStatus, string> = {
  all: "كل الحالات",
  upcoming: "قادمة",
  live: "مباشرة",
  finished: "منتهية",
};

const navItems = [
  { label: "نظرة عامة", icon: LayoutDashboard },
  { label: "المباريات", icon: Trophy },
  { label: "الترشيحات", icon: Target },
];

function formatDate(date: string) {
  try {
    return new Intl.DateTimeFormat("ar-EG", { weekday: "short", day: "numeric", month: "short" }).format(new Date(`${date}T12:00:00`));
  } catch {
    return date;
  }
}

function formatUpdated(date: string) {
  try {
    return new Intl.DateTimeFormat("ar-EG", { hour: "2-digit", minute: "2-digit" }).format(new Date(date));
  } catch {
    return "الآن";
  }
}

function StatusPill({ status }: { status: MatchStatus }) {
  const live = status === "live";
  const label = status === "live" ? "مباشرة" : status === "finished" ? "انتهت" : "قادمة";
  return <span className={`status-pill status-${status}`}><span className={live ? "pulse-dot" : "status-dot"} />{label}</span>;
}

function FormDots({ form }: { form: string[] }) {
  return (
    <div className="form-dots" aria-label="الفورمة الأخيرة">
      {form.map((result, index) => <span key={`${result}-${index}`} className={`form-dot form-${result}`} title={result === "W" ? "فوز" : result === "D" ? "تعادل" : "خسارة"}>{result}</span>)}
    </div>
  );
}

function TeamMark({ team, small = false }: { team: Team; small?: boolean }) {
  return <div className={`team-mark ${small ? "team-mark-small" : ""}`} style={{ "--team-color": team.color } as React.CSSProperties}>{team.shortName.slice(0, 3)}</div>;
}

function StrengthBar({ team, compact = false }: { team: Team; compact?: boolean }) {
  return (
    <div className={`strength-row ${compact ? "compact" : ""}`}>
      <div className="strength-heading"><span>{team.name}</span><strong>{team.strength}<small>/100</small></strong></div>
      <div className="meter"><span style={{ width: `${team.strength}%`, background: team.color }} /></div>
      {!compact && <div className="strength-meta"><span>ترتيب الدوري #{team.rank}</span><FormDots form={team.form} /></div>}
    </div>
  );
}

function MatchCard({ match, onOpen }: { match: Match; onOpen: () => void }) {
  const homeLead = match.home.strength >= match.away.strength;
  return (
    <button className="match-card" onClick={onOpen} type="button">
      <div className="match-card-top"><span className="league-label"><span className="league-dot" />{match.league}</span><StatusPill status={match.status} /></div>
      <div className="match-time"><CalendarDays size={13} /> {formatDate(match.date)} <span /> <Clock3 size={13} /> {match.kickoff}</div>
      <div className="teams-line">
        <div className="team-side"><TeamMark team={match.home} small /><span>{match.home.name}</span></div>
        <div className="versus">VS</div>
        <div className="team-side team-side-away"><span>{match.away.name}</span><TeamMark team={match.away} small /></div>
      </div>
      <div className="card-strengths"><div><span>قوة {homeLead ? "الأرض" : "الضيف"}</span><b>{Math.max(match.home.strength, match.away.strength)}</b></div><div className="mini-meter"><span style={{ width: `${Math.max(match.home.strength, match.away.strength)}%` }} /></div></div>
      <div className="match-card-foot"><span><Activity size={14} /> {match.venue}</span><span className="open-arrow">التفاصيل <ChevronLeft size={15} /></span></div>
    </button>
  );
}

function CircularConfidence({ confidence, strength }: { confidence: number; strength: Prediction["strength"] }) {
  const radius = 43;
  const circumference = 2 * Math.PI * radius;
  const dash = circumference * confidence / 100;
  return (
    <div className={`confidence-ring ring-${strength}`} style={{ "--dash": `${dash}px`, "--circumference": `${circumference}px` } as React.CSSProperties}>
      <svg viewBox="0 0 104 104" aria-hidden="true"><circle className="ring-track" cx="52" cy="52" r={radius} /><circle className="ring-value" cx="52" cy="52" r={radius} /></svg>
      <div className="confidence-number"><strong>{confidence}%</strong><span>ثقة</span></div>
    </div>
  );
}

function PredictionCard({ prediction }: { prediction: Prediction }) {
  return (
    <section className="prediction-card">
      <div className="prediction-glow" />
      <div className="section-eyebrow"><span className="eyebrow-icon"><BrainCircuit size={16} /></span>ترشيح MatchIQ <span className="ai-chip"><Sparkles size={11} /> AI ديناميكي</span></div>
      <div className="prediction-main">
        <CircularConfidence confidence={prediction.confidence} strength={prediction.strength} />
        <div className="prediction-copy"><span className="prediction-market">{prediction.market} · {prediction.horizon}</span><h2>{prediction.selection}</h2><div className={`strength-badge strength-${prediction.strength}`}><span />ثقة {prediction.strength}</div></div>
      </div>
      <div className="prediction-divider" />
      <div className="prediction-section"><h3><Zap size={15} /> لماذا هذا الاختيار؟</h3>{prediction.rationale.map((item, index) => <p key={item}><span>0{index + 1}</span>{item}</p>)}</div>
      <div className="prediction-section risk-section"><h3><AlertTriangle size={15} /> نقاط عدم اليقين</h3>{prediction.risks.map(item => <p key={item}><span>!</span>{item}</p>)}</div>
      <div className="model-foot"><span><ShieldCheck size={14} /> جودة البيانات {prediction.dataQuality}%</span><span>{prediction.model}</span></div>
    </section>
  );
}

function StatBar({ label, home, away, suffix = "" }: { label: string; home: number; away: number; suffix?: string }) {
  const total = Math.max(home + away, 1);
  const homeWidth = Math.round(home / total * 100);
  return <div className="stat-bar-row"><div className="stat-values"><strong>{home}{suffix}</strong><span>{label}</span><strong>{away}{suffix}</strong></div><div className="dual-bar"><span className="dual-home" style={{ width: `${homeWidth}%` }} /><span className="dual-away" style={{ width: `${100 - homeWidth}%` }} /></div></div>;
}

function Overview({ matches, onOpen, onRefresh, loading }: { matches: Match[]; onOpen: (id: string) => void; onRefresh: () => void; loading: boolean }) {
  const liveCount = matches.filter(match => match.status === "live").length;
  const averageStrength = matches.length ? Math.round(matches.reduce((sum, match) => sum + match.home.strength + match.away.strength, 0) / matches.length / 2) : 0;
  return (
    <>
      <header className="page-header">
        <div><div className="breadcrumb"><span>لوحة التحليل</span><ChevronLeft size={14} /><strong>المباريات اليوم</strong></div><h1>مركز المباريات <span className="headline-mark">.</span></h1><p>قراءة سريعة للسوق قبل صافرة البداية — اختر المباراة لعرض التحليل الكامل.</p></div>
        <div className="header-actions"><span className="last-sync"><span className="sync-dot" /> آخر تحديث {matches[0] ? formatUpdated(matches[0].lastUpdated) : "--:--"}</span><button className="icon-button" type="button" onClick={onRefresh} aria-label="تحديث" disabled={loading}><RefreshCw size={18} className={loading ? "spin" : ""} /></button></div>
      </header>
      <div className="metric-strip"><div className="metric-item"><div className="metric-icon metric-green"><Activity size={18} /></div><div><span>مباريات اليوم</span><strong>{matches.length.toString().padStart(2, "0")}</strong></div><small>من مصادر متعددة</small></div><div className="metric-item"><div className="metric-icon metric-blue"><Gauge size={18} /></div><div><span>متوسط القوة</span><strong>{averageStrength}<small>/100</small></strong></div><small>حسب النموذج</small></div><div className="metric-item"><div className="metric-icon metric-amber"><Zap size={18} /></div><div><span>مباشر الآن</span><strong>{liveCount.toString().padStart(2, "0")}</strong></div><small>تتبع لحظي</small></div><div className="metric-item metric-highlight"><div className="metric-icon metric-violet"><BrainCircuit size={18} /></div><div><span>ترشيحات جاهزة</span><strong>{Math.min(matches.length, 12).toString().padStart(2, "0")}</strong></div><small>تحليل احتمالي</small></div></div>
      <div className="content-heading"><div><span className="section-kicker">إشارة اليوم</span><h2>مباريات تستحق القراءة</h2></div><span className="result-count">{matches.length} نتائج</span></div>
      {loading ? <div className="loading-grid">{[1, 2, 3].map(item => <div className="skeleton-card" key={item}><span /><span /><span /><span /></div>)}</div> : matches.length === 0 ? <EmptyState /> : <div className="matches-grid">{matches.map(match => <MatchCard key={match.id} match={match} onOpen={() => onOpen(match.id)} />)}</div>}
      <div className="dashboard-footnote"><CircleHelp size={15} /><span>البيانات التجريبية موسومة داخل الموقع عند عدم إعداد مزود API. الترشيحات احتمالات تحليلية وليست ضمانًا للنتيجة أو الربح.</span></div>
    </>
  );
}

function EmptyState() {
  return <div className="empty-state"><div className="empty-icon"><Search size={24} /></div><h3>لا توجد مباريات بهذه الفلاتر</h3><p>غيّر اليوم أو الدوري أو حالة المباراة لتظهر نتائج أخرى.</p></div>;
}

function MatchDetail({ match, prediction, loading, onBack }: { match?: Match; prediction?: Prediction; loading: boolean; onBack: () => void }) {
  if (loading || !match) return <div className="detail-loading"><RefreshCw size={23} className="spin" /><span>نجهز قراءة المباراة...</span></div>;
  const totalGoals = (match.homeStats.goalsFor + match.awayStats.goalsFor).toFixed(1);
  return (
    <>
      <header className="detail-header"><button className="back-button" type="button" onClick={onBack}><ArrowLeft size={17} /> العودة للمباريات</button><div className="detail-head-meta"><span>{match.league}</span><span className="meta-separator" /><span>{formatDate(match.date)} · {match.kickoff}</span><StatusPill status={match.status} /></div></header>
      <section className="match-hero"><div className="hero-topline"><span className="league-label"><span className="league-dot" />{match.venue}</span><span className="demo-label"><span />{match.source === "demo" ? "بيانات تجريبية" : "بيانات مزود API"}</span></div><div className="hero-teams"><div className="hero-team"><TeamMark team={match.home} /><h1>{match.home.name}</h1><span>ترتيب #{match.home.rank}</span></div><div className="hero-score"><span>مباراة {match.status === "live" ? "جارية" : "قادمة"}</span><strong>—</strong><small>{match.kickoff}</small></div><div className="hero-team hero-team-away"><TeamMark team={match.away} /><h1>{match.away.name}</h1><span>ترتيب #{match.away.rank}</span></div></div><div className="hero-strengths"><StrengthBar team={match.home} /><div className="strength-vs">قوة</div><StrengthBar team={match.away} /></div></section>
      <div className="detail-layout"><div className="detail-main"><section className="panel"><div className="panel-header"><div><span className="section-kicker">مؤشرات المباراة</span><h2>الملف الإحصائي</h2></div><span className="panel-caption">آخر 5 مباريات</span></div><div className="stat-bars"><StatBar label="الأهداف المتوقعة" home={match.homeStats.goalsFor} away={match.awayStats.goalsFor} /><StatBar label="التسديدات" home={match.homeStats.shots} away={match.awayStats.shots} /><StatBar label="تسديدات على المرمى" home={match.homeStats.shotsOnTarget} away={match.awayStats.shotsOnTarget} /><StatBar label="الركنيات" home={match.homeStats.corners} away={match.awayStats.corners} /><StatBar label="الأخطاء" home={match.homeStats.fouls} away={match.awayStats.fouls} /></div><div className="half-grid"><div><span>الشوط الأول</span><strong>{match.homeStats.firstHalfGoals.toFixed(1)} <em>—</em> {match.awayStats.firstHalfGoals.toFixed(1)}</strong><small>متوسط الأهداف</small></div><div><span>الشوط الثاني</span><strong>{match.homeStats.secondHalfGoals.toFixed(1)} <em>—</em> {match.awayStats.secondHalfGoals.toFixed(1)}</strong><small>متوسط الأهداف</small></div><div><span>الاستحواذ</span><strong>{match.homeStats.possession}% <em>—</em> {match.awayStats.possession}%</strong><small>متوسط آخر 5</small></div></div></section><section className="panel split-panel"><div className="sub-panel"><div className="sub-panel-title"><Users size={16} /> الفورمة الأخيرة</div><div className="form-team"><span>{match.home.name}</span><FormDots form={match.home.form} /></div><div className="form-team"><span>{match.away.name}</span><FormDots form={match.away.form} /></div></div><div className="sub-panel h2h-panel"><div className="sub-panel-title"><TrendingUp size={16} /> H2H <span>آخر {match.h2h.length}</span></div>{match.h2h.slice(0, 3).map(game => <div className="h2h-row" key={`${game.date}-${game.home}`}><span>{formatDate(game.date)}</span><strong>{game.home} <em>{game.score}</em> {game.away}</strong><b className={game.winner === "draw" ? "draw-result" : ""}>{game.winner === "draw" ? "تعادل" : game.winner === "home" ? "فوز المضيف" : "فوز الضيف"}</b></div>)}</div></section><section className="panel availability-panel"><div className="panel-header"><div><span className="section-kicker">سياق المباراة</span><h2>الغيابات والحالة</h2></div><span className="panel-caption">تُحدّث عند توافرها</span></div><div className="injury-list">{match.injuries.map(item => <div key={item}><span className="injury-dot" />{item}</div>)}</div></section></div><aside className="detail-aside"><PredictionCard prediction={prediction ?? { market: "قيد التحليل", selection: "نجهز الترشيح", confidence: 0, strength: "ضعيف", probability: 0, horizon: "—", rationale: [], risks: [], dataQuality: 0, model: "—" }} /><div className="aside-note"><CloudOff size={15} /><span>لا تتعامل مع الترشيح كضمان. حدّد ميزانية مخاطرتك ولا تطارد الخسائر.</span></div><div className="quick-read"><div><span>إجمالي الأهداف المتوقع</span><strong>{totalGoals}</strong></div><div><span>ركنيات متوقعة</span><strong>{(match.homeStats.corners + match.awayStats.corners).toFixed(1)}</strong></div></div></aside></div>
    </>
  );
}

export default function Home() {
  const [, setLocation] = useLocation();
  const [matchRoute, matchParams] = useRoute<{ id: string }>("/match/:id");
  const selectedId = matchRoute ? matchParams?.id : undefined;
  const [mobileNav, setMobileNav] = useState(false);
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [league, setLeague] = useState("all");
  const [status, setStatus] = useState<FilterStatus>("all");
  const [date, setDate] = useState("");

  const filters = useMemo(() => ({ league, status, ...(date ? { date } : {}) }), [date, league, status]);
  const listQuery = trpc.matches.list.useQuery(filters, { staleTime: 60_000 });
  const providerQuery = trpc.provider.status.useQuery(undefined, { staleTime: 60_000 });
  const detailQuery = trpc.matches.detail.useQuery({ id: selectedId ?? "" }, { enabled: Boolean(selectedId), staleTime: 60_000 });
  const predictionQuery = trpc.matches.analyze.useQuery({ id: selectedId ?? "" }, { enabled: Boolean(selectedId), staleTime: 60_000 });
  const matches = listQuery.data ?? [];
  const leagues = Array.from(new Set(matches.map(match => match.league)));

  const openMatch = (id: string) => { setLocation(`/match/${id}`); setMobileNav(false); window.scrollTo({ top: 0, behavior: "smooth" }); };
  const backToMatches = () => setLocation("/");

  return (
    <div className="app-shell" dir="rtl">
      <aside className={`sidebar ${mobileNav ? "sidebar-open" : ""}`}>
        <div className="brand"><div className="brand-mark"><span /><span /><i /></div><div><strong>Match<span>IQ</span></strong><small>FOOTBALL INTELLIGENCE</small></div><button className="mobile-close" type="button" onClick={() => setMobileNav(false)}><X size={18} /></button></div>
        <div className="sidebar-section"><span className="sidebar-label">مساحة العمل</span>{navItems.map((item, index) => <button className={`nav-item ${index === 0 && !selectedId ? "nav-active" : ""}`} type="button" key={item.label} onClick={() => { if (index < 2) setLocation("/"); setMobileNav(false); }}><item.icon size={18} /><span>{item.label}</span>{index === 1 && <b>{matches.length}</b>}</button>)}</div>
        <div className="sidebar-section sidebar-section-lower"><span className="sidebar-label">النظام</span><button className="nav-item" type="button" onClick={() => setFiltersOpen(true)}><Settings2 size={18} /><span>إعدادات المزود</span>{providerQuery.data?.configured ? <span className="config-ok"><Check size={12} /></span> : <span className="config-warn">!</span>}</button><button className="nav-item" type="button"><CircleHelp size={18} /><span>كيف نحلل؟</span></button></div>
        <div className="sidebar-bottom"><div className={`connection-card ${providerQuery.data?.configured ? "connected" : "demo"}`}><div className="connection-icon">{providerQuery.data?.configured ? <Check size={15} /> : <CloudOff size={15} />}</div><div><strong>{providerQuery.data?.configured ? "مزود API متصل" : "وضع البيانات التجريبية"}</strong><span>{providerQuery.data?.configured ? "آخر مزامنة ناجحة" : "أضف التوكن لبيانات حقيقية"}</span></div></div><div className="profile-chip"><div className="profile-avatar">M</div><div><strong>محلل MatchIQ</strong><span>خطة الاستكشاف</span></div><ChevronLeft size={15} /></div></div>
      </aside>
      {mobileNav && <button className="mobile-scrim" type="button" aria-label="إغلاق القائمة" onClick={() => setMobileNav(false)} />}
      <main className="main-content"><div className="mobile-topbar"><button className="icon-button" type="button" onClick={() => setMobileNav(true)}><Menu size={20} /></button><div className="mobile-brand">Match<span>IQ</span></div><button className="icon-button" type="button" onClick={() => setFiltersOpen(true)}><SlidersHorizontal size={19} /></button></div>{selectedId ? <MatchDetail match={detailQuery.data} prediction={predictionQuery.data} loading={detailQuery.isLoading || predictionQuery.isLoading} onBack={backToMatches} /> : <><div className="filter-bar"><div className="filter-search"><Search size={16} /><input placeholder="ابحث عن فريق أو دوري..." aria-label="البحث" /><kbd>⌘ K</kbd></div><div className="filter-controls"><select value={date} onChange={event => setDate(event.target.value)} aria-label="التاريخ"><option value="">كل التواريخ</option>{[0, 1, 2, 3, 4].map(offset => <option key={offset} value={new Date(Date.now() + offset * 86_400_000).toISOString().slice(0, 10)}>{offset === 0 ? "اليوم" : formatDate(new Date(Date.now() + offset * 86_400_000).toISOString().slice(0, 10))}</option>)}</select><select value={league} onChange={event => setLeague(event.target.value)} aria-label="الدوري"><option value="all">كل الدوريات</option>{leagues.map(item => <option key={item} value={item}>{item}</option>)}</select><select value={status} onChange={event => setStatus(event.target.value as FilterStatus)} aria-label="الحالة">{Object.entries(statusLabel).map(([key, label]) => <option value={key} key={key}>{label}</option>)}</select><button className="filter-more" type="button" onClick={() => setFiltersOpen(true)}><SlidersHorizontal size={16} /> المزيد</button></div></div><Overview matches={matches} onOpen={openMatch} onRefresh={() => listQuery.refetch()} loading={listQuery.isLoading} /></>}</main>
      {filtersOpen && <div className="settings-overlay" role="dialog" aria-modal="true"><div className="settings-modal"><div className="modal-head"><div><span className="section-kicker">إعدادات التكامل</span><h2>مزود البيانات</h2></div><button className="icon-button" type="button" onClick={() => setFiltersOpen(false)}><X size={18} /></button></div><div className="settings-status"><div className={`status-symbol ${providerQuery.data?.configured ? "status-symbol-ok" : "status-symbol-demo"}`}>{providerQuery.data?.configured ? <Check size={20} /> : <CloudOff size={20} />}</div><div><strong>{providerQuery.data?.configured ? "المزود جاهز للاتصال" : "لم يتم إعداد مزود API بعد"}</strong><p>{providerQuery.data?.configured ? "المفتاح مخزن في الخادم ولا يتم إرساله للمتصفح." : "الموقع يعمل ببيانات تجريبية حتى تضيف إعدادات المزود بأمان."}</p></div></div><label>اسم المزود<input placeholder="مثال: API-Football" /></label><label>Base URL<input placeholder="يُحفظ كسر خادمي" type="url" /></label><label>API Token<input placeholder="لا تكتبه في الدردشة — استخدم أسرار المشروع" type="password" /></label><div className="secure-note"><ShieldCheck size={16} /><span>لا تُدخل التوكن في واجهة عامة أو داخل Git. عند تزويدي باسم المزود وعقد الـAPI، أجهز الربط عبر أسرار الخادم.</span></div><button className="primary-action" type="button" onClick={() => setFiltersOpen(false)}>حفظ الإعدادات <ArrowLeft size={16} /></button></div></div>}
    </div>
  );
}
