import { ENV } from "./_core/env";
import { invokeLLM } from "./_core/llm";

export type MatchStatus = "upcoming" | "live" | "finished";
export type Strength = "قوي" | "متوسط" | "ضعيف";

export type Team = {
  name: string;
  shortName: string;
  providerId?: number;
  color: string;
  form: string[];
  strength: number;
  rank: number;
};

export type TeamStats = {
  goalsFor: number;
  goalsAgainst: number;
  shots: number;
  shotsOnTarget: number;
  corners: number;
  fouls: number;
  possession: number;
  firstHalfGoals: number;
  secondHalfGoals: number;
};

export type H2HGame = {
  date: string;
  home: string;
  away: string;
  score: string;
  winner: "home" | "away" | "draw";
};

export type Match = {
  id: string;
  providerHomeId?: number;
  providerAwayId?: number;
  providerLeagueId?: number;
  league: string;
  country: string;
  date: string;
  kickoff: string;
  status: MatchStatus;
  venue: string;
  home: Team;
  away: Team;
  homeStats: TeamStats;
  awayStats: TeamStats;
  h2h: H2HGame[];
  injuries: string[];
  source: "demo" | "provider";
  lastUpdated: string;
};

export type Prediction = {
  market: string;
  selection: string;
  confidence: number;
  strength: Strength;
  probability: number;
  horizon: string;
  rationale: string[];
  risks: string[];
  dataQuality: number;
  model: string;
};

const now = new Date();
const isoDate = (offset: number) => {
  const value = new Date(now);
  value.setDate(value.getDate() + offset);
  return value.toISOString().slice(0, 10);
};

const team = (name: string, shortName: string, color: string, form: string[], strength: number, rank: number): Team => ({
  name,
  shortName,
  color,
  form,
  strength,
  rank,
});

const stats = (goalsFor: number, goalsAgainst: number, shots: number, shotsOnTarget: number, corners: number, fouls: number, possession: number, firstHalfGoals: number, secondHalfGoals: number): TeamStats => ({
  goalsFor, goalsAgainst, shots, shotsOnTarget, corners, fouls, possession, firstHalfGoals, secondHalfGoals,
});

const h2h = (games: Array<[string, string, string, H2HGame["winner"]]>): H2HGame[] => games.map(([date, home, away, winner], index) => ({
  date,
  home,
  away,
  score: index % 2 === 0 ? "2 - 1" : "1 - 1",
  winner,
}));

const demoMatches: Match[] = [
  {
    id: "demo-arsenal-chelsea",
    league: "الدوري الإنجليزي الممتاز",
    country: "إنجلترا",
    date: isoDate(0),
    kickoff: "21:00",
    status: "upcoming",
    venue: "ملعب الإمارات",
    home: team("آرسنال", "ARS", "#ef4444", ["W", "W", "D", "W", "W"], 86, 2),
    away: team("تشيلسي", "CHE", "#3b82f6", ["W", "D", "L", "W", "D"], 78, 6),
    homeStats: stats(2.1, 0.8, 15.8, 6.2, 6.8, 9.5, 57, 1.0, 1.1),
    awayStats: stats(1.7, 1.1, 13.1, 4.9, 5.4, 11.2, 53, 0.8, 0.9),
    h2h: h2h([["2026-09-21", "تشيلسي", "آرسنال", "away"], ["2026-03-16", "آرسنال", "تشيلسي", "draw"], ["2025-11-30", "تشيلسي", "آرسنال", "home"], ["2025-05-04", "آرسنال", "تشيلسي", "home"]]),
    injuries: ["ساكا — جاهزية تحت التقييم", "كول بالمر — متاح"],
    source: "demo",
    lastUpdated: new Date().toISOString(),
  },
  {
    id: "demo-barca-atletico",
    league: "الدوري الإسباني",
    country: "إسبانيا",
    date: isoDate(1),
    kickoff: "22:00",
    status: "upcoming",
    venue: "لويس كومبانيس الأولمبي",
    home: team("برشلونة", "BAR", "#2563eb", ["W", "W", "W", "L", "W"], 88, 1),
    away: team("أتلتيكو مدريد", "ATM", "#dc2626", ["W", "D", "W", "W", "D"], 84, 3),
    homeStats: stats(2.4, 0.9, 16.4, 6.8, 7.1, 10.1, 61, 1.2, 1.2),
    awayStats: stats(1.9, 0.7, 12.8, 5.4, 5.8, 13.4, 48, 0.9, 1.0),
    h2h: h2h([["2026-08-24", "أتلتيكو مدريد", "برشلونة", "draw"], ["2026-02-10", "برشلونة", "أتلتيكو مدريد", "home"], ["2025-12-01", "أتلتيكو مدريد", "برشلونة", "away"], ["2025-03-02", "برشلونة", "أتلتيكو مدريد", "home"]]),
    injuries: ["بيدري — غير مؤكد", "أوبلاك — متاح"],
    source: "demo",
    lastUpdated: new Date().toISOString(),
  },
  {
    id: "demo-liverpool-city",
    league: "الدوري الإنجليزي الممتاز",
    country: "إنجلترا",
    date: isoDate(2),
    kickoff: "18:30",
    status: "upcoming",
    venue: "أنفيلد",
    home: team("ليفربول", "LIV", "#dc2626", ["W", "W", "W", "W", "D"], 90, 1),
    away: team("مانشستر سيتي", "MCI", "#06b6d4", ["D", "W", "W", "L", "W"], 89, 3),
    homeStats: stats(2.6, 0.9, 17.2, 7.1, 6.4, 8.7, 54, 1.2, 1.4),
    awayStats: stats(2.2, 1.0, 18.1, 6.9, 7.3, 8.2, 62, 1.0, 1.2),
    h2h: h2h([["2026-09-01", "مانشستر سيتي", "ليفربول", "draw"], ["2026-02-08", "ليفربول", "مانشستر سيتي", "home"], ["2025-12-14", "مانشستر سيتي", "ليفربول", "away"], ["2025-04-13", "ليفربول", "مانشستر سيتي", "home"]]),
    injuries: ["ترينت — عودة قريبة", "رودري — جاهزية تحت التقييم"],
    source: "demo",
    lastUpdated: new Date().toISOString(),
  },
  {
    id: "demo-inter-milan",
    league: "الدوري الإيطالي",
    country: "إيطاليا",
    date: isoDate(3),
    kickoff: "20:45",
    status: "live",
    venue: "سان سيرو",
    home: team("إنتر ميلان", "INT", "#1d4ed8", ["W", "W", "D", "W", "W"], 87, 1),
    away: team("ميلان", "MIL", "#ef4444", ["L", "W", "D", "W", "L"], 79, 7),
    homeStats: stats(2.0, 0.6, 14.7, 5.7, 6.1, 12.2, 56, 0.9, 1.1),
    awayStats: stats(1.5, 1.4, 11.4, 4.2, 4.9, 13.6, 49, 0.7, 0.8),
    h2h: h2h([["2026-10-18", "ميلان", "إنتر ميلان", "away"], ["2026-05-11", "إنتر ميلان", "ميلان", "home"], ["2026-01-06", "ميلان", "إنتر ميلان", "draw"], ["2025-09-22", "إنتر ميلان", "ميلان", "home"]]),
    injuries: ["ثيو هيرنانديز — غائب", "باستوني — متاح"],
    source: "demo",
    lastUpdated: new Date().toISOString(),
  },
  {
    id: "demo-bayern-dortmund",
    league: "الدوري الألماني",
    country: "ألمانيا",
    date: isoDate(4),
    kickoff: "19:30",
    status: "finished",
    venue: "أليانز أرينا",
    home: team("بايرن ميونخ", "BAY", "#ef4444", ["W", "W", "L", "W", "W"], 89, 1),
    away: team("بوروسيا دورتموند", "BVB", "#eab308", ["W", "D", "L", "W", "D"], 81, 4),
    homeStats: stats(2.7, 1.0, 19.2, 7.4, 8.1, 8.8, 59, 1.4, 1.3),
    awayStats: stats(1.8, 1.3, 13.7, 5.1, 5.7, 12.7, 46, 0.8, 1.0),
    h2h: h2h([["2026-09-20", "بوروسيا دورتموند", "بايرن ميونخ", "away"], ["2026-03-15", "بايرن ميونخ", "بوروسيا دورتموند", "home"], ["2025-11-08", "بوروسيا دورتموند", "بايرن ميونخ", "draw"], ["2025-04-12", "بايرن ميونخ", "بوروسيا دورتموند", "home"]]),
    injuries: ["هاري كين — سجل هدفًا", "جوليان براندت — متاح"],
    source: "demo",
    lastUpdated: new Date().toISOString(),
  },
];

function toNumber(value: unknown, fallback = 0): number {
  const parsed = typeof value === "number" ? value : Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
}

function normalizeForm(value: unknown): string[] {
  if (!Array.isArray(value)) return ["W", "D", "W", "L", "W"];
  return value.slice(0, 5).map(item => String(item).toUpperCase().slice(0, 1));
}

function normalizeTeam(value: any, fallback: Team): Team {
  if (!value || typeof value !== "object") return fallback;
  return {
    ...fallback,
    name: String(value.name ?? value.team?.name ?? fallback.name),
    shortName: String(value.shortName ?? value.code ?? value.team?.code ?? fallback.shortName),
    providerId: toNumber(value.providerId ?? value.id ?? value.team?.id, fallback.providerId),
    form: normalizeForm(value.form ?? value.recentForm),
    strength: toNumber(value.strength, fallback.strength),
    rank: toNumber(value.rank ?? value.position, fallback.rank),
  };
}

export function normalizeProviderResponse(raw: unknown): Match[] {
  const payload = raw as any;
  const items = Array.isArray(payload) ? payload : payload?.matches ?? payload?.fixtures ?? payload?.data ?? payload?.results;
  if (!Array.isArray(items) || items.length === 0) return [];

  return items.slice(0, 100).map((item: any, index: number): Match => {
    const sportApiHome = item.home_team ? { name: item.home_team, shortName: item.home_short, id: item.home_id } : undefined;
    const sportApiAway = item.away_team ? { name: item.away_team, shortName: item.away_short, id: item.away_id } : undefined;
    const home = normalizeTeam(sportApiHome ?? item.homeTeam ?? item.home ?? item.teams?.home, demoMatches[index % demoMatches.length].home);
    const away = normalizeTeam(sportApiAway ?? item.awayTeam ?? item.away ?? item.teams?.away, demoMatches[index % demoMatches.length].away);
    const status = String(item.status ?? item.fixture?.status?.short ?? "NS").toLowerCase();
    const mappedStatus: MatchStatus = status.includes("live") || ["1h", "2h", "ht", "et"].includes(status) ? "live" : status.includes("finished") || ["ft", "aet", "pen", "pens"].includes(status) ? "finished" : "upcoming";
    const base = demoMatches[index % demoMatches.length];
    return {
      ...base,
      providerHomeId: toNumber(item.home_id ?? home.providerId, base.home.providerId),
      providerAwayId: toNumber(item.away_id ?? away.providerId, base.away.providerId),
      providerLeagueId: toNumber(item.league_id, base.providerLeagueId),
      id: String(item.id ?? item.fixture?.id ?? `provider-${index}`),
      league: String(item.league_name ?? item.league?.name ?? item.competition?.name ?? item.league ?? base.league),
      country: String(item.league_zone ?? item.league?.country ?? item.country ?? base.country),
      date: String(item.date ?? item.fixture?.date ?? base.date).slice(0, 10),
      kickoff: String(item.datetime ?? item.kickoff_utc ?? item.kickoff ?? item.fixture?.date ?? base.kickoff).slice(11, 16) || base.kickoff,
      status: mappedStatus,
      venue: String(item.venue?.name ?? item.fixture?.venue?.name ?? item.venue ?? base.venue),
      home,
      away,
      source: "provider",
      lastUpdated: new Date().toISOString(),
    };
  });
}

const isSportApi = () => (process.env.FOOTBALL_API_PROVIDER ?? "").toLowerCase().includes("sportapi") || (process.env.FOOTBALL_API_BASE_URL ?? "").includes("sportapi.ai");

async function fetchProviderJson(path: string): Promise<any> {
  const baseUrl = process.env.FOOTBALL_API_BASE_URL;
  const token = process.env.FOOTBALL_API_TOKEN;
  if (!baseUrl || !token) return null;
  const normalizedBase = baseUrl.endsWith("/") ? baseUrl : `${baseUrl}/`;
  const url = new URL(path.replace(/^\/+/, ""), normalizedBase).toString();
  const response = await fetch(url, {
    headers: {
      ...(isSportApi() ? { "X-Api-Key": token } : { Authorization: `Bearer ${token}`, "X-API-Key": token }),
      Accept: "application/json",
    },
    signal: AbortSignal.timeout(12_000),
  });
  if (!response.ok) throw new Error(`Provider request failed (${response.status})`);
  const body = await response.json();
  if (body?.success === false) throw new Error(body.error ?? "Provider returned an error");
  return body;
}

async function fetchProviderMatches(date?: string): Promise<Match[]> {
  const baseUrl = process.env.FOOTBALL_API_BASE_URL;
  const token = process.env.FOOTBALL_API_TOKEN;
  if (!baseUrl || !token) return [];
  const path = isSportApi() ? `/fixtures/date/${date ?? isoDate(0)}` : (process.env.FOOTBALL_API_MATCHES_PATH ?? "/matches");
  return normalizeProviderResponse(await fetchProviderJson(path));
}

function parseSportApiStats(raw: any, homeFallback: TeamStats, awayFallback: TeamStats): { home: TeamStats; away: TeamStats } {
  const data = raw?.data ?? raw;
  const home = data?.home ?? data?.home_team ?? data?.teams?.home ?? {};
  const away = data?.away ?? data?.away_team ?? data?.teams?.away ?? {};
  const read = (value: any, keys: string[], fallbackValue: number) => {
    for (const key of keys) if (value?.[key] !== undefined) return toNumber(value[key], fallbackValue);
    return fallbackValue;
  };
  const parse = (value: any, base: TeamStats): TeamStats => ({
    ...base,
    shots: read(value, ["shots", "total_shots"], base.shots),
    shotsOnTarget: read(value, ["shots_on_target", "shotsOnTarget"], base.shotsOnTarget),
    corners: read(value, ["corners", "corner_kicks"], base.corners),
    fouls: read(value, ["fouls", "fouls_committed"], base.fouls),
    possession: read(value, ["possession", "possession_pct"], base.possession),
  });
  return { home: parse(home, homeFallback), away: parse(away, awayFallback) };
}

function parseSportApiH2H(raw: any, match: Match): H2HGame[] {
  const items = raw?.data ?? raw?.matches ?? raw?.fixtures ?? [];
  if (!Array.isArray(items)) return [];
  return items.slice(0, 8).map((item: any): H2HGame => {
    const homeScore = item.home_score ?? item.score?.fulltime?.home ?? "?";
    const awayScore = item.away_score ?? item.score?.fulltime?.away ?? "?";
    const winner = item.winner === "home" || item.result === 1 ? "home" : item.winner === "away" || item.result === -1 ? "away" : "draw";
    return {
      date: String(item.date ?? item.datetime ?? "").slice(0, 10),
      home: String(item.home_team ?? item.home ?? match.home.name),
      away: String(item.away_team ?? item.away ?? match.away.name),
      score: `${homeScore} - ${awayScore}`,
      winner,
    };
  });
}

export async function getMatches(filters?: { date?: string; league?: string; status?: MatchStatus | "all" }): Promise<Match[]> {
  try {
    const providerMatches = await fetchProviderMatches(filters?.date);
    const source = providerMatches.length > 0 ? providerMatches : demoMatches;
    return source.filter(match => {
      if (filters?.date && match.date !== filters.date) return false;
      if (filters?.league && filters.league !== "all" && match.league !== filters.league) return false;
      if (filters?.status && filters.status !== "all" && match.status !== filters.status) return false;
      return true;
    });
  } catch (error) {
    console.warn("[Football] Falling back to demo data:", error instanceof Error ? error.message : error);
    return demoMatches.filter(match => {
      if (filters?.date && match.date !== filters.date) return false;
      if (filters?.league && filters.league !== "all" && match.league !== filters.league) return false;
      if (filters?.status && filters.status !== "all" && match.status !== filters.status) return false;
      return true;
    });
  }
}

export async function getMatch(id: string): Promise<Match | undefined> {
  const matches = await getMatches();
  const match = matches.find(candidate => candidate.id === id) ?? demoMatches.find(candidate => candidate.id === id);
  if (!match || match.source !== "provider" || !isSportApi() || !match.providerHomeId || !match.providerAwayId) return match;
  try {
    const [h2hResponse, statsResponse] = await Promise.all([
      fetchProviderJson(`/fixtures/h2h/${match.providerHomeId}/${match.providerAwayId}`),
      fetchProviderJson(`/fixtures/${match.id}/stats`),
    ]);
    const h2hGames = parseSportApiH2H(h2hResponse, match);
    const parsedStats = parseSportApiStats(statsResponse, match.homeStats, match.awayStats);
    return { ...match, h2h: h2hGames.length ? h2hGames : match.h2h, homeStats: parsedStats.home, awayStats: parsedStats.away };
  } catch (error) {
    console.warn("[Football] Optional SportAPI enrichment failed:", error instanceof Error ? error.message : error);
    return match;
  }
}

function averageForm(form: string[]): number {
  return form.reduce((sum, result) => sum + (result === "W" ? 3 : result === "D" ? 1 : 0), 0) / Math.max(form.length, 1) / 3;
}

function clamp(value: number, min = 0, max = 100) {
  return Math.min(max, Math.max(min, Math.round(value)));
}

export function analyzeMatch(match: Match): Prediction {
  const formEdge = averageForm(match.home.form) - averageForm(match.away.form);
  const rankEdge = (match.away.rank - match.home.rank) / 20;
  const strengthEdge = (match.home.strength - match.away.strength) / 100;
  const goalEdge = (match.homeStats.goalsFor - match.awayStats.goalsFor) / 4;
  const h2hHome = match.h2h.filter(game => game.winner === "home" || game.home === match.home.name).length;
  const h2hAway = match.h2h.filter(game => game.winner === "away" || game.away === match.away.name).length;
  const h2hEdge = (h2hHome - h2hAway) / Math.max(match.h2h.length, 1);
  const homeEdge = strengthEdge * 0.36 + formEdge * 0.26 + rankEdge * 0.15 + goalEdge * 0.13 + h2hEdge * 0.1;
  const homeWin = clamp(50 + homeEdge * 44, 34, 78);
  const awayWin = clamp(50 - homeEdge * 38, 15, 49);
  const draw = clamp(100 - homeWin - awayWin, 16, 34);
  const totalGoals = match.homeStats.goalsFor + match.awayStats.goalsFor;
  const totalCorners = match.homeStats.corners + match.awayStats.corners;
  const totalFouls = match.homeStats.fouls + match.awayStats.fouls;

  const options = [
    { market: "النتيجة النهائية", selection: `${match.home.name} أو تعادل`, probability: clamp(homeWin + draw, 55, 88), score: Math.abs(homeEdge) * 0.7 + 0.1, horizon: "الوقت العادي", why: `أفضلية الأرض والفورمة تميل إلى ${match.home.name} مع هامش حماية من التعادل.` },
    { market: "مجموع الأهداف", selection: totalGoals >= 3.2 ? "أكثر من 2.5 هدف" : "أقل من 3.5 هدف", probability: clamp(totalGoals >= 3.2 ? 58 + totalGoals * 4 : 68 - totalGoals * 2, 55, 81), score: 0.54 + Math.abs(totalGoals - 2.7) * 0.1, horizon: "الوقت العادي", why: `متوسط التسجيل المتوقع ${totalGoals.toFixed(1)} هدف مع توازن بين جودة الفرص.` },
    { market: "الركنيات", selection: totalCorners >= 12 ? "أكثر من 9.5 ركنية" : "أقل من 12.5 ركنية", probability: clamp(totalCorners >= 12 ? 62 + (totalCorners - 12) * 2 : 64, 55, 79), score: 0.57 + Math.min(Math.abs(totalCorners - 10) / 25, 0.16), horizon: "الوقت العادي", why: `حجم التسديد واللعب على الأطراف يرفع توقع الركنيات إلى ${totalCorners.toFixed(1)}.` },
    { market: "أهداف الشوط الأول", selection: (match.homeStats.firstHalfGoals + match.awayStats.firstHalfGoals) >= 1.8 ? "أكثر من 0.5 هدف" : "أقل من 1.5 هدف", probability: 59 + Math.round(Math.min(16, Math.abs(match.homeStats.firstHalfGoals + match.awayStats.firstHalfGoals - 1.5) * 7)), score: 0.55 + Math.abs(match.homeStats.firstHalfGoals + match.awayStats.firstHalfGoals - 1.5) * 0.08, horizon: "الشوط الأول", why: "التوزيع التهديفي المبكر يعطي إشارة مستقلة عن نتيجة المباراة الكاملة." },
    { market: "الأخطاء", selection: totalFouls >= 24 ? "أكثر من 22.5 خطأ" : "أقل من 27.5 خطأ", probability: clamp(61 + Math.abs(totalFouls - 24), 55, 76), score: 0.53 + Math.min(Math.abs(totalFouls - 24) / 30, 0.18), horizon: "الوقت العادي", why: `معدل الالتحامات المتوقع يقارب ${totalFouls.toFixed(0)} خطأ، لكن السوق شديد الحساسية للحكم.` },
  ];

  const best = options.sort((a, b) => b.score - a.score)[0];
  const dataQuality = clamp(78 + (match.source === "provider" ? 12 : 0) - (match.injuries.length === 0 ? 8 : 0), 54, 96);
  const confidence = clamp(best.probability * 0.66 + dataQuality * 0.34, 55, 88);
  const strength: Strength = confidence >= 76 ? "قوي" : confidence >= 65 ? "متوسط" : "ضعيف";

  return {
    market: best.market,
    selection: best.selection,
    confidence,
    strength,
    probability: best.probability,
    horizon: best.horizon,
    rationale: [
      best.why,
      `فارق القوة التقديري ${Math.abs(homeEdge * 100).toFixed(0)} نقطة، مع فورمة ${match.home.name} (${match.home.form.join(" ")}) مقابل ${match.away.name} (${match.away.form.join(" ")}).`,
      `المواجهات المباشرة الأخيرة تميل إلى ${h2hHome >= h2hAway ? match.home.name : match.away.name} لكن وزنها أقل من الأداء الحالي.`,
    ],
    risks: [
      "تشكيلات البداية والغيابات المؤكدة قد تغيّر التوقع قبل المباراة.",
      "الأسواق الإحصائية مثل الركنيات والأخطاء أكثر تقلبًا من سوق النتيجة.",
      "الاحتمال ليس ضمانًا للنتيجة أو للربح؛ استخدم إدارة مخاطر مسؤولة.",
    ],
    dataQuality,
    model: "MatchIQ Probabilistic v1",
  };
}

const AI_PREDICTION_SCHEMA = {
  name: "football_match_prediction",
  strict: true,
  schema: {
    type: "object",
    properties: {
      market: { type: "string" },
      selection: { type: "string" },
      confidence: { type: "integer", minimum: 0, maximum: 100 },
      probability: { type: "integer", minimum: 0, maximum: 100 },
      horizon: { type: "string" },
      rationale: { type: "array", items: { type: "string" }, minItems: 2, maxItems: 4 },
      risks: { type: "array", items: { type: "string" }, minItems: 2, maxItems: 4 },
      dataQuality: { type: "integer", minimum: 0, maximum: 100 },
    },
    required: ["market", "selection", "confidence", "probability", "horizon", "rationale", "risks", "dataQuality"],
    additionalProperties: false,
  },
} as const;

function extractLLMText(result: Awaited<ReturnType<typeof invokeLLM>>): string {
  const content = result.choices?.[0]?.message?.content;
  if (typeof content === "string") return content;
  if (Array.isArray(content)) return content.map(part => part.type === "text" ? part.text : "").join("\n");
  return "";
}

function parsePredictionJson(text: string): Omit<Prediction, "strength" | "model"> {
  const cleaned = text.replace(/^```json\s*/i, "").replace(/```$/i, "").trim();
  const start = cleaned.indexOf("{");
  const end = cleaned.lastIndexOf("}");
  if (start < 0 || end <= start) throw new Error("AI returned no JSON prediction");
  const parsed = JSON.parse(cleaned.slice(start, end + 1));
  const list = (value: unknown, minimum: number) => {
    if (!Array.isArray(value) || value.length < minimum) throw new Error("AI prediction has incomplete explanation");
    return value.slice(0, 4).map(item => String(item));
  };
  if (!parsed.market || !parsed.selection || !parsed.horizon) throw new Error("AI prediction is missing market fields");
  return {
    market: String(parsed.market),
    selection: String(parsed.selection),
    confidence: clamp(toNumber(parsed.confidence), 0, 100),
    probability: clamp(toNumber(parsed.probability), 0, 100),
    horizon: String(parsed.horizon),
    rationale: list(parsed.rationale, 2),
    risks: list(parsed.risks, 2),
    dataQuality: clamp(toNumber(parsed.dataQuality), 0, 100),
  };
}

export async function analyzeMatchWithAI(match: Match): Promise<Prediction> {
  const input = {
    competition: match.league,
    country: match.country,
    date: match.date,
    kickoff: match.kickoff,
    status: match.status,
    home: { name: match.home.name, rank: match.home.rank, strength: match.home.strength, form: match.home.form, stats: match.homeStats },
    away: { name: match.away.name, rank: match.away.rank, strength: match.away.strength, form: match.away.form, stats: match.awayStats },
    h2h: match.h2h,
    injuries: match.injuries,
    source: match.source,
    marketFamilies: ["النتيجة النهائية والفرصة المزدوجة", "مجموع الأهداف وأهداف الشوط الأول/الثاني", "الهاندكاب", "الركنيات", "الأخطاء", "النتيجة الصحيحة"],
  };
  try {
    const response = await invokeLLM({
      model: "gpt-5.5",
      reasoning: { effort: "high" },
      messages: [
        { role: "system", content: "أنت محلل كرة قدم احتمالي حذر. حلل البيانات المقدمة فقط، ولا تستخدم ترشيحًا ثابتًا أو تختار دائمًا السوق نفسه. اختر بنفسك السوق والاختيار الأكثر ملاءمة لهذه المباراة حسب قوة الإشارة وجودة البيانات. لا تخترع odds أو إصابات أو إحصاءات. إذا كانت البيانات ضعيفة اخفض confidence وdataQuality. لا تضمن الربح. أخرج JSON مطابقًا للمخطط فقط." },
        { role: "user", content: JSON.stringify(input, null, 2) },
      ],
      response_format: { type: "json_schema", json_schema: AI_PREDICTION_SCHEMA },
    });
    const prediction = parsePredictionJson(extractLLMText(response));
    const strength: Strength = prediction.confidence >= 76 ? "قوي" : prediction.confidence >= 65 ? "متوسط" : "ضعيف";
    return { ...prediction, strength, model: "gpt-5.5 — AI dynamic analyst" };
  } catch (error) {
    console.warn("[Football] AI analysis failed; using statistical safety fallback:", error instanceof Error ? error.message : error);
    const fallback = analyzeMatch(match);
    return { ...fallback, confidence: Math.min(fallback.confidence, 58), strength: "ضعيف", model: "Statistical fallback — AI unavailable", rationale: ["لم يكتمل تحليل الذكاء الاصطناعي، لذلك تم خفض الثقة تلقائيًا.", ...fallback.rationale.slice(0, 2)], risks: ["لا تعتمد على هذا الترشيح قبل عودة تحليل الذكاء الاصطناعي.", ...fallback.risks.slice(0, 2)] };
  }
}

export function getProviderStatus() {
  return {
    configured: Boolean(process.env.FOOTBALL_API_BASE_URL && process.env.FOOTBALL_API_TOKEN),
    provider: process.env.FOOTBALL_API_PROVIDER ?? "لم يتم اختيار مزود",
    baseUrl: process.env.FOOTBALL_API_BASE_URL ? "مُعدّ — مخفي" : "غير مُعدّ",
    lastSync: new Date().toISOString(),
    demoMode: !(process.env.FOOTBALL_API_BASE_URL && process.env.FOOTBALL_API_TOKEN),
    platformAiReady: Boolean(ENV.forgeApiUrl && ENV.forgeApiKey),
  };
}
