import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { analyzeMatchWithAI, getMatch, getMatches, getProviderStatus, type MatchStatus } from "./football";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  matches: router({
    list: publicProcedure
      .input(z.object({
        date: z.string().optional(),
        league: z.string().optional(),
        status: z.enum(["upcoming", "live", "finished", "all"]).optional(),
      }).optional())
      .query(({ input }) => getMatches(input)),
    detail: publicProcedure
      .input(z.object({ id: z.string().min(1) }))
      .query(async ({ input }) => {
        const match = await getMatch(input.id);
        if (!match) throw new Error("لم يتم العثور على المباراة");
        return match;
      }),
    analyze: publicProcedure
      .input(z.object({ id: z.string().min(1) }))
      .query(async ({ input }) => {
        const match = await getMatch(input.id);
        if (!match) throw new Error("لم يتم العثور على المباراة");
        return analyzeMatchWithAI(match);
      }),
  }),
  provider: router({
    status: publicProcedure.query(() => getProviderStatus()),
  }),
});

export type AppRouter = typeof appRouter;
